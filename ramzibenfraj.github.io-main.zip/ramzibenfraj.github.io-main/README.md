<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> mon cv</title>
    <link rel="stylesheet" href="wrapcv.css">
</head>
<body>
    <div id="titre">
        <h1> MON CV</h1>
        <div class="photo">
            <img src="cv.jpg" alt="">
        </div>
        <div class="about">
            <h2>DONNER PERSONNELLE</h2>
            <p>nom : Benfradj</p>
            <p>prenom : Ramzi </p>
            <p>Age : 23</p>
            <p>Adresse :benkhair nabeul</p>

        </div>
        <div class="exp">
            <div class="cv">
                <h2> MON CV</h2>
                <p>HTML , CSS , C# ,JAVAFX ,PYTHON</p>
                <p>UML , SQL ,LINUX </p>
            </div>
            <div class="competence">
                <h2> MES COMPETENCES</h2>
                <p>solidworks , autocad </p>
            </div>
            <div class="button">
                <h2>MES CONNTES</h2>
                <a href="https://www.facebook.com/ramzi.Benfraj.77"><button>facebook</button></a>
                <a href="https://www.instagram.com/ramzi_benfarj/"><button>instagram</button></a>
            </div>

        </div>
        

    </div>

</body>
</html>
